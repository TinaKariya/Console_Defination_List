﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Co_defination6
{
    class Program
    {
        static void Main(string[] args)
        {
            //while loop
            int k = 1;
            while (k <= 5)
            {
                int l = 1;
                while (l <= k)
                {
                    Console.Write(l);
                    l++;
                }
                Console.WriteLine();
                k++;
            }
            //do while loop
            int m = 1;
            do
            {
                int n = 1;
                do
                {
                    Console.Write(n);
                    n++;
                } while (n <= m);
                Console.WriteLine();
                m++;
            } while (m <= 5);

            Console.Read();
        }
    }
}
