﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Co_defination13
{
    class Program
    {
       
        public static void HaveAnice()
        {
            Console.WriteLine("Wellcome to Geetanjali Collage ");
            Console.WriteLine("Have a Wounderfull Day");
        }
        public static void Main(string[] args)
        {
	      Console.Write(" Enter User name : \n");
	      string str1;
		
          Console.Write("Please input a name : ");
          str1 = Console.ReadLine();	  
          HaveAnice();
          Console.ReadKey();
        }
      }
    }
