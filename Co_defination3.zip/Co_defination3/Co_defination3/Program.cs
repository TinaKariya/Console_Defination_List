﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Co_defination3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("input value of A & B:");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            c = a + b;
            Console.WriteLine("Addition="+c);

            c = a - b;
            Console.WriteLine("Subtraction=" + c);

            c = a * b;
            Console.WriteLine("Multiplication=" + c);

            c = a / b;
            Console.WriteLine("Division=" + c);

            c = a % b;
            Console.WriteLine("Modulas=" + c);
            Console.ReadKey();
        }
    }
}
