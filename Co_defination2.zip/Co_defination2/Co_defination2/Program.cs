﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Co_defination2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name     : Tina kariya");
            Console.WriteLine("Roll no  :30");
            Console.WriteLine("Course   :BCA");
            Console.WriteLine("Sem      :4th");
            Console.WriteLine("Division :B");
            Console.ReadKey();
        }
    }
}
