﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Co_defination4
{
    class Program
    {
        static void Main(string[] args)
        {
            int net, cs, os, java, total;
            string grade, result;
            double per;

            Console.Write("Enter Marks For Networking : ");
            net = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Marks For C Sharp : ");
            cs = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Marks For Operating System : ");
            os = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Marks For Java : ");
            java = Convert.ToInt32(Console.ReadLine());

            total = net + cs + os + java;

            if (net >= 40 && cs >= 40 && java >= 40 && os >= 40)
            {
                result = "PASS";
                per = total / 4;
                if (per >= 70)
                {
                    grade = "Dist.";
                }
                else if (per >= 60)
                {
                    grade = "First";
                }
                else if (per >= 50)
                {
                    grade = "Second";
                }
                else
                {
                    grade = "PASS";
                }
            }
            else
            {
                result = "FAIL";
                grade = "-";
                per = 0.0;
            }

            Console.WriteLine("Your Total is :" + total);
            Console.WriteLine("Your Percentage is : " + per);
            Console.WriteLine("Your Grade is : " + grade);
            Console.WriteLine("Your Result is : " + result);
            Console.ReadKey();
        }
    }
}
